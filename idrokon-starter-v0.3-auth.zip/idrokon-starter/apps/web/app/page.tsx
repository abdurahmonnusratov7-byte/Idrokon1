const topics = ["Science", "History", "Nature", "Universe", "Technology", "Humanity"];

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <header className="bg-ink px-6 py-5 text-ivory md:px-12">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div>
            <div className="text-3xl font-semibold tracking-wide">IDROKON<span className="text-gold">.</span></div>
            <p className="mt-1 text-xs tracking-[.25em] text-gold">TRUTH. EVIDENCE. DISCOVERY.</p>
          </div>
          <nav className="hidden gap-6 text-sm md:flex">
            <a href="#">Discover</a><a href="#">Science</a><a href="#">History</a><a href="#">Magazine</a>
          </nav>
          <div className="rounded-full border border-gold px-3 py-1 text-sm">EN / UZ</div>
        </div>
      </header>
      <section className="bg-ink px-6 py-20 text-ivory md:px-12">
        <div className="mx-auto grid max-w-7xl gap-10 md:grid-cols-2 md:items-center">
          <div>
            <p className="mb-4 text-xs tracking-[.25em] text-gold">INDEPENDENT SCIENTIFIC & DOCUMENTARY MEDIA</p>
            <h1 className="max-w-2xl text-5xl leading-tight md:text-7xl">The world, examined closer.</h1>
            <p className="mt-6 max-w-xl text-lg text-slate-300">Research-led stories about science, history, nature, the universe, technology and humanity.</p>
            <a className="mt-8 inline-block rounded-full bg-gold px-6 py-3 font-semibold text-ink" href="/articles">Explore discoveries</a>
          </div>
          <div className="rounded-2xl border border-slate-600 bg-slateblue/30 p-8">
            <p className="text-sm tracking-widest text-gold">EDITOR'S FEATURE</p>
            <h2 className="mt-4 text-3xl">Beyond the known universe</h2>
            <p className="mt-3 text-slate-300">A sample feature area. Connect verified editorial content before publication.</p>
          </div>
        </div>
      </section>
      <section className="mx-auto max-w-7xl px-6 py-16 md:px-12">
        <div className="mb-8 flex items-end justify-between"><h2 className="text-3xl">Explore topics</h2><span className="text-sm text-slate-500">EN · UZ</span></div>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3">{topics.map(topic => <div key={topic} className="rounded-xl border border-stone-300 bg-white/70 p-6 text-xl">{topic}</div>)}</div>
      </section>
      <footer className="bg-ink px-6 py-10 text-center text-ivory"><p className="text-xl">IDROKON.</p><p className="mt-2 text-xs tracking-[.25em] text-gold">TRUTH. EVIDENCE. DISCOVERY.</p></footer>
    </main>
  );
}

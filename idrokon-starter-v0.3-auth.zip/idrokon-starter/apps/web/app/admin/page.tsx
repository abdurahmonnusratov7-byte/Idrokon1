const stats = [
  ["Articles in progress", "12", "+3 this week"],
  ["Awaiting fact-check", "5", "Needs review"],
  ["Scheduled publications", "4", "Next release: Saturday"],
  ["Magazine issues", "08", "Archive editions"],
];

const tasks = [
  ["Sunday", "Topic selection & initial research", "Planning"],
  ["Monday", "Deep research & source collection", "Research"],
  ["Tuesday", "Article and documentary scripts", "Writing"],
  ["Wednesday", "Claim-by-claim fact-checking", "Verification"],
  ["Thursday", "Visual production & layouts", "Production"],
  ["Friday", "Bilingual editorial review", "Final review"],
  ["Saturday", "Website, magazine & social release", "Publication"],
];

const content = [
  ["The Mystery of Black Holes", "Science", "Fact-check"],
  ["Lost Cities of the Silk Road", "History", "Draft"],
  ["How the Human Brain Forms Memories", "Humanity", "Editorial review"],
];

export default function AdminDashboard() {
  return (
    <div className="mx-auto max-w-7xl space-y-8">
      <section className="flex flex-wrap items-end justify-between gap-4">
        <div><p className="text-xs font-semibold tracking-[.2em] text-[#997644]">IDROKON / CONTROL CENTER</p><h1 className="mt-2 text-3xl font-semibold md:text-4xl">Good day, Editorial Team.</h1><p className="mt-2 text-sm text-slate-600">Your weekly production overview, from Sunday through Saturday.</p></div>
        <button className="rounded-full bg-[#0B1D2E] px-5 py-3 text-sm font-semibold text-white">＋ Create content</button>
      </section>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map(([label, value, note]) => <div key={label} className="rounded-2xl border border-stone-300 bg-white p-5 shadow-sm"><p className="text-sm text-slate-500">{label}</p><p className="mt-3 text-3xl font-semibold text-[#0B1D2E]">{value}</p><p className="mt-2 text-xs text-[#997644]">{note}</p></div>)}
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.35fr_1fr]">
        <div className="rounded-2xl border border-stone-300 bg-white p-5">
          <div className="flex items-center justify-between gap-3"><div><h2 className="text-xl font-semibold">Weekly production</h2><p className="mt-1 text-xs text-slate-500">The IDROKON publishing cycle</p></div><span className="rounded-full bg-[#F3EFE6] px-3 py-1 text-xs">Sunday → Saturday</span></div>
          <div className="mt-5 space-y-3">{tasks.map(([day, task, stage], index) => <div key={day} className="flex items-center gap-3 rounded-xl bg-[#F8F6F1] p-3"><div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-xs font-bold ${index === 6 ? "bg-[#C9A76A] text-[#0B1D2E]" : "bg-[#0B1D2E] text-white"}`}>{index + 1}</div><div className="min-w-0 flex-1"><p className="text-sm font-semibold">{day}</p><p className="text-xs text-slate-600">{task}</p></div><span className="hidden rounded-full border border-stone-300 px-2 py-1 text-[10px] text-slate-600 sm:block">{stage}</span></div>)}</div>
        </div>

        <div className="space-y-6">
          <div className="rounded-2xl bg-[#0B1D2E] p-5 text-white"><p className="text-xs tracking-[.2em] text-[#C9A76A]">EDITORIAL PRINCIPLE</p><h2 className="mt-3 text-2xl">Truth. Evidence. Discovery.</h2><p className="mt-3 text-sm leading-6 text-slate-300">No AI-generated draft is marked verified automatically. Claims need traceable sources and human editorial approval.</p></div>
          <div className="rounded-2xl border border-stone-300 bg-white p-5"><h2 className="text-xl font-semibold">Recent content</h2><div className="mt-4 space-y-4">{content.map(([title, category, status]) => <div key={title} className="border-b border-stone-200 pb-3 last:border-0 last:pb-0"><p className="text-sm font-semibold">{title}</p><div className="mt-2 flex items-center justify-between gap-2 text-xs text-slate-500"><span>{category}</span><span className="rounded-full bg-[#F3EFE6] px-2 py-1">{status}</span></div></div>)}</div></div>
        </div>
      </section>
      <p className="text-xs text-slate-500">Prototype dashboard using sample data. Authentication, role-based permissions and live database connections are not enabled yet.</p>
    </div>
  );
}

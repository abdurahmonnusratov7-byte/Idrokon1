export default function Page() {
  return <section className="max-w-3xl rounded-2xl border border-stone-300 bg-white p-8">
    <p className="text-xs font-semibold tracking-widest text-[#997644]">IDROKON CONTROL CENTER</p>
    <h1 className="mt-3 text-3xl font-semibold">Team & Roles</h1>
    <p className="mt-3 text-slate-600">Manage editorial team roles and permissions.</p>
    <div className="mt-8 rounded-xl bg-[#F3EFE6] p-4 text-sm text-slate-600">Module planned. Connect this page to the API and database in the next implementation step.</div>
  </section>;
}

export default function Page() {
  return <section className="max-w-3xl rounded-2xl border border-stone-300 bg-white p-8">
    <p className="text-xs font-semibold tracking-widest text-[#997644]">IDROKON CONTROL CENTER</p>
    <h1 className="mt-3 text-3xl font-semibold">Magazine Manager</h1>
    <p className="mt-3 text-slate-600">Build weekly issues and manage Web, PDF and Flipbook editions.</p>
    <div className="mt-8 rounded-xl bg-[#F3EFE6] p-4 text-sm text-slate-600">Module planned. Connect this page to the API and database in the next implementation step.</div>
  </section>;
}

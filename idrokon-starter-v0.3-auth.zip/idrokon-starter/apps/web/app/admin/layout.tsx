import Link from "next/link";

const nav = [
  ["Overview", "/admin"],
  ["Content Hub", "/admin/content"],
  ["Magazine", "/admin/magazine"],
  ["Documentary Studio", "/admin/documentary"],
  ["Research & Sources", "/admin/research"],
  ["Fact-checking", "/admin/fact-check"],
  ["Production Calendar", "/admin/calendar"],
  ["Media Library", "/admin/media"],
  ["Subscriptions", "/admin/subscriptions"],
  ["Analytics", "/admin/analytics"],
  ["Team & Roles", "/admin/team"],
  ["Settings", "/admin/settings"],
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-[#F3EFE6] md:grid md:grid-cols-[250px_1fr]">
      <aside className="bg-[#0B1D2E] p-5 text-[#F3EFE6]">
        <Link href="/" className="block text-2xl font-semibold tracking-wide">IDROKON<span className="text-[#C9A76A]">.</span></Link>
        <p className="mb-8 mt-1 text-[10px] tracking-[.2em] text-[#C9A76A]">CONTROL CENTER</p>
        <nav className="grid grid-cols-2 gap-1 md:grid-cols-1">
          {nav.map(([label, href]) => (
            <Link key={href} href={href} className="rounded-lg px-3 py-2 text-sm text-slate-200 transition hover:bg-white/10 hover:text-white">{label}</Link>
          ))}
        </nav>
        <div className="mt-8 rounded-xl border border-white/15 p-3">
          <p className="text-xs font-semibold text-[#C9A76A]">EDITORIAL STANDARD</p>
          <p className="mt-2 text-xs leading-5 text-slate-300">Truth. Evidence. Discovery. AI drafts require human review before publication.</p>
        </div>
      </aside>
      <div className="min-w-0">
        <header className="flex items-center justify-between border-b border-stone-300 bg-white/70 px-6 py-4">
          <div><p className="text-xs uppercase tracking-widest text-stone-500">Independent Scientific & Documentary Media</p><p className="font-semibold">Editorial workspace</p></div>
          <div className="rounded-full border border-stone-300 px-3 py-1 text-xs">EN / UZ · Demo</div>
        </header>
        <main className="p-5 md:p-8">{children}</main>
      </div>
    </div>
  );
}

import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "IDROKON — Truth. Evidence. Discovery.",
  description: "Independent scientific and documentary media in English and Uzbek."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}

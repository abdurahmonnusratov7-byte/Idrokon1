import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: { extend: { colors: { ink: "#0B1D2E", slateblue: "#3A5A78", gold: "#C9A76A", ivory: "#F3EFE6" } } },
  plugins: []
};
export default config;

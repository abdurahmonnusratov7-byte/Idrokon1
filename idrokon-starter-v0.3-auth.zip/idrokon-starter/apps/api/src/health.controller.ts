import { Controller, Get } from "@nestjs/common";
@Controller("health")
export class HealthController {
  @Get()
  getHealth() {
    return { service: "IDROKON API", status: "ok", version: "0.1.0" };
  }
}

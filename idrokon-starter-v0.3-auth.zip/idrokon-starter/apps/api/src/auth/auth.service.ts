import { Injectable, UnauthorizedException } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import * as bcrypt from "bcrypt";
import { PrismaService } from "../prisma/prisma.service";
import { LoginDto } from "./dto/login.dto";

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
  ) {}

  async login(dto: LoginDto) {
    const user = await this.prisma.user.findUnique({
      where: { email: dto.email.toLowerCase().trim() },
    });

    // Use the same public error for unknown email and wrong password.
    if (!user || !user.isActive || !user.passwordHash) {
      throw new UnauthorizedException("Email yoki parol noto‘g‘ri.");
    }

    const valid = await bcrypt.compare(dto.password, user.passwordHash);
    if (!valid) throw new UnauthorizedException("Email yoki parol noto‘g‘ri.");

    const accessToken = await this.jwt.signAsync({
      sub: user.id,
      role: user.role,
    });

    await this.prisma.auditLog.create({
      data: {
        userId: user.id,
        action: "AUTH_LOGIN",
        entity: "User",
        entityId: user.id,
      },
    });

    return {
      accessToken,
      user: {
        id: user.id,
        email: user.email,
        displayName: user.displayName,
        role: user.role,
      },
    };
  }
}

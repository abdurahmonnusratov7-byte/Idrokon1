import { SetMetadata } from "@nestjs/common";

export const ROLES_KEY = "roles";
export type UserRole =
  | "SUPER_ADMIN"
  | "EDITOR_IN_CHIEF"
  | "EDITOR"
  | "RESEARCHER"
  | "FACT_CHECKER"
  | "WRITER"
  | "TRANSLATOR"
  | "DESIGNER"
  | "VIDEO_EDITOR"
  | "PUBLISHER"
  | "SUBSCRIBER";

export const Roles = (...roles: UserRole[]) => SetMetadata(ROLES_KEY, roles);

# IDROKON — Starter Architecture

A bilingual (English/Uzbek) editorial media platform starter.

## Stack
- Web: Next.js App Router + TypeScript + Tailwind CSS
- API: NestJS + TypeScript
- Database: PostgreSQL + Prisma
- Local services: Docker Compose

## Project structure
- `apps/web` — public website and future admin UI
- `apps/api` — backend API
- `packages/database` — shared Prisma schema and client
- `docs` — architecture notes

## Start locally
1. Install Node.js 20+ and Docker.
2. Copy `.env.example` to `.env` and update secrets.
3. Start PostgreSQL: `docker compose up -d postgres`
4. Install dependencies from the root: `npm install`
5. Generate Prisma client: `npm run db:generate`
6. Apply schema: `npm run db:migrate`
7. Start apps: `npm run dev`

The initial scaffold is a foundation, not a production-ready deployment. Add authentication, validation, rate limiting, backups, tests, storage, and payment-provider integration before launch.


## v0.3 Authentication groundwork
See `docs/authentication-v0.3.md` for API login, JWT, role guards, setup, and production limitations. The admin UI is not yet wired to this API.

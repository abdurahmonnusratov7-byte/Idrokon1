# Architecture decisions

## Publishing model
An article is language-neutral at its core. `ArticleTranslation` stores the English and Uzbek editorial versions. Sources and claims attach to the canonical article so both editions share a fact-check record.

## Editorial integrity
- Drafts are never publicly visible.
- Publication requires an explicit approval step.
- Every factual claim should be linked to one or more sources.
- AI output is an editorial draft, not verified evidence.
- Keep an audit trail for editorial changes.

## Weekly cycle
Sunday: topic selection and initial research
Monday: deep research
Tuesday: writing and scripts
Wednesday: fact-checking
Thursday: visual production
Friday: final editorial review
Saturday: publication

## Before production launch
Add authentication, RBAC guards, input validation, CSRF protection where applicable, rate limiting, secure secret management, object-storage policies, automated backups, observability, tests, and payment webhook verification.

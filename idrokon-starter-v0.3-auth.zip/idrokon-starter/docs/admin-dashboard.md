# Admin Dashboard Prototype

The `/admin` route now includes:
- Hybrid dark/light editorial shell
- Navigation for core publishing modules
- Weekly production overview (Sunday–Saturday)
- Sample editorial metrics and content list

All metrics and content are demonstration data. This is not authenticated and must not be exposed as a production admin area until authentication, server-side role checks, input validation, audit logging and tests are implemented.

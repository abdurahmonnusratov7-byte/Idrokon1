# IDROKON Authentication Foundation — v0.3

This increment adds API-side authentication groundwork. It is not a production-ready identity system yet.

## Included
- `POST /api/auth/login`: checks an active user's bcrypt password hash and returns a 15-minute JWT.
- `GET /api/auth/me`: validates the bearer token and returns the current user.
- `GET /api/auth/admin-check`: example route restricted to Super Admin and Editor-in-Chief.
- Prisma service/module for PostgreSQL access.
- DTO validation with unknown fields rejected.
- Audit record for successful logins.
- Role decorator and role guard for route-level authorization.

## Required environment
Set `DATABASE_URL`, `JWT_SECRET`, `WEB_ORIGIN`, and `API_PORT` in your local `.env`.
`JWT_SECRET` must be a unique, random secret with at least 32 characters. Never commit `.env`.

## Run locally
1. Install dependencies from the repository root: `npm install`.
2. Generate Prisma client: `npm run db:generate`.
3. Apply the database migration: `npm run db:migrate`.
4. Start the API: `npm run start:dev --workspace @idrokon/api`.

## Create the first administrator safely
There is deliberately no public sign-up or public administrator-creation endpoint.
Create the first administrator through a trusted, one-time operator procedure:
- Generate a bcrypt password hash in a secure local environment.
- Insert the user with `role = SUPER_ADMIN`, `isActive = true`, and that hash.
- Do not place a real password or hash in source control, screenshots, or shared chat.
- Require a unique password and enable hosting-level access controls around the database.

## Important limitations before production
- Add login rate limiting and temporary lockout / abuse monitoring.
- Add refresh-token rotation or a secure server-side session strategy; current access tokens expire after 15 minutes.
- Add password reset and administrator provisioning workflows.
- Add security headers, HTTPS-only deployment, secret rotation, and security logging.
- Review CORS origins for each deployment; never use wildcard origins with credentials.
- Add automated tests for login, disabled users, expiry, and every role boundary.
- The example `/admin-check` route is a demonstration of RBAC, not a complete permission matrix.
- The browser dashboard is still a prototype and is not yet connected to this authentication API.

Do not deploy this increment publicly until the missing controls above are implemented and reviewed.
